
import openai

client = openai.OpenAI(api_key="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")

try:
    response = client.chat.completions.create(
        model="gpt-4o-mini",  # Change to "gpt-3.5-turbo-1106" if needed
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hello, how many students are registered in the database?"}
        ]
    )
    
    print("✅ API Call Successful! Response:")
    print(response.choices[0].message.content)

except openai.OpenAIError as e:
    print(f"❌ API Error: {e}")
