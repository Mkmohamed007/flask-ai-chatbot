

import openai

client = openai.OpenAI(api_key="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")

try:
    response = client.models.list()
    print("✅ Your API Key is working! Available Models:")
    for model in response.data:
        print(model.id)
except openai.OpenAIError as e:
    print(f"❌ API Error: {e}")
