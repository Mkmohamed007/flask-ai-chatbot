import requests

API_URL = "http://127.0.0.1:5001/chat"

def chat_with_ai(prompt):
    response = requests.post(API_URL, json={"prompt": prompt})
    return response.json()

# Example Usage
result = chat_with_ai("List all students with their grades.")
print(result)

